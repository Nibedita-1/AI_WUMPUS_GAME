import random
import pygame
import time
import heapq

# Game constants
GRID_SIZE = 4
TILE_SIZE = 100
NUM_PITS = 2
NUM_WUMPUS = 1
NUM_GOLD = 1

# Directions for the AI to move
MOVES = [(0, 1), (0, -1), (1, 0), (-1, 0)]  # Right, Left, Down, Up

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
GRAY = (169, 169, 169)

class WumpusWorld:
    def __init__(self):
        self.grid = [['' for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
        self.agent_pos = (0, 0)  # Start at the top-left corner
        self.wumpus_pos = None
        self.pit_positions = []
        self.gold_pos = None
        self.visited = set()
        self.score = 0
        self.game_over = False
        self.success_message = ""

        self._generate_world()

    def _generate_world(self):
        # Randomly place the Wumpus, pits, and gold
        self.wumpus_pos = self._random_empty_tile()
        self.grid[self.wumpus_pos[0]][self.wumpus_pos[1]] = 'W'

        self.pit_positions = [self._random_empty_tile() for _ in range(NUM_PITS)]
        for pit in self.pit_positions:
            self.grid[pit[0]][pit[1]] = 'P'

        self.gold_pos = self._random_empty_tile()
        self.grid[self.gold_pos[0]][self.gold_pos[1]] = 'G'

    def _random_empty_tile(self):
        while True:
            x = random.randint(0, GRID_SIZE - 1)
            y = random.randint(0, GRID_SIZE - 1)
            if self.grid[x][y] == '':
                return (x, y)

    def get_tile_info(self, x, y):
        if (x, y) == self.agent_pos:
            return 'A'  # Agent's position
        elif (x, y) == self.wumpus_pos:
            return 'W'
        elif (x, y) in self.pit_positions:
            return 'P'
        elif (x, y) == self.gold_pos:
            return 'G'
        return ''

    def is_valid_move(self, x, y):
        return 0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE

    def get_adjacent_tiles(self, x, y):
        adj_tiles = []
        for dx, dy in MOVES:
            nx, ny = x + dx, y + dy
            if self.is_valid_move(nx, ny):
                adj_tiles.append((nx, ny))
        return adj_tiles

    def draw(self, screen, font):
        for row in range(GRID_SIZE):
            for col in range(GRID_SIZE):
                tile = pygame.Rect(col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                pygame.draw.rect(screen, WHITE, tile, 2)

                # Draw content (Wumpus, Pit, Gold, Agent)
                content = self.get_tile_info(row, col)
                if content == 'W':
                    pygame.draw.circle(screen, RED, tile.center, TILE_SIZE // 3)
                    label = font.render("W", True, WHITE)
                    screen.blit(label, label.get_rect(center=tile.center))
                elif content == 'P':
                    pygame.draw.circle(screen, BLUE, tile.center, TILE_SIZE // 3)
                    label = font.render("P", True, WHITE)
                    screen.blit(label, label.get_rect(center=tile.center))
                elif content == 'G':
                    pygame.draw.circle(screen, YELLOW, tile.center, TILE_SIZE // 3)
                    label = font.render("G", True, BLACK)
                    screen.blit(label, label.get_rect(center=tile.center))
                elif content == 'A':
                    pygame.draw.circle(screen, GREEN, tile.center, TILE_SIZE // 3)
                    label = font.render("A", True, WHITE)
                    screen.blit(label, label.get_rect(center=tile.center))

        # Draw score and game status
        score_text = font.render(f"Score: {self.score}", True, WHITE)
        screen.blit(score_text, (10, 10))
        
        if self.game_over:
            status_text = font.render(self.success_message, True, YELLOW)
            screen.blit(status_text, (GRID_SIZE * TILE_SIZE // 4, GRID_SIZE * TILE_SIZE // 2))

    def get_cost(self, x, y):
        if (x, y) == self.wumpus_pos or (x, y) in self.pit_positions:
            return float('inf')  # High cost for dangerous tiles
        elif (x, y) == self.gold_pos:
            return 0  # No cost for the goal (gold)
        return 1  # Default cost for safe tiles

# A* algorithm to find the safest path to the gold
def a_star(world):
    start = world.agent_pos
    goal = world.gold_pos

    # Priority queue for open nodes
    open_list = []
    heapq.heappush(open_list, (0, start))

    # Dictionaries to store g(x), f(x) and parents
    g_costs = {start: 0}
    f_costs = {start: manhattan_distance(start, goal)}
    came_from = {}

    while open_list:
        _, current = heapq.heappop(open_list)
        
        if current == goal:
            # Reconstruct path
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.reverse()
            return path

        for neighbor in world.get_adjacent_tiles(current[0], current[1]):
            g = g_costs[current] + world.get_cost(neighbor[0], neighbor[1])
            h = manhattan_distance(neighbor, goal)
            f = g + h

            if neighbor not in g_costs or g < g_costs[neighbor]:
                g_costs[neighbor] = g
                f_costs[neighbor] = f
                came_from[neighbor] = current
                heapq.heappush(open_list, (f, neighbor))

    return []  # No path found

# Manhattan distance heuristic
def manhattan_distance(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

# AI moves along the path returned by A*
def ai_move(world):
    path = a_star(world)
    if path:
        next_move = path[0]  # Take the next step in the path
        world.agent_pos = next_move
        world.visited.add(next_move)

        # Check if the AI has reached the goal or encountered danger
        if next_move == world.gold_pos:
            world.score += 100  # Reward for finding the gold
            world.success_message = "Success! You found the gold!"
            world.game_over = True
        elif next_move in world.pit_positions:
            world.score -= 50  # Penalty for falling into a pit
            world.success_message = "Failure! You fell into a pit."
            world.game_over = True
        elif next_move == world.wumpus_pos:
            world.score -= 100  # Penalty for encountering the Wumpus
            world.success_message = "Failure! You were killed by the Wumpus."
            world.game_over = True

# Draw start and pause buttons
def draw_buttons(screen, font, game_paused):
    start_button = pygame.Rect(50, GRID_SIZE * TILE_SIZE + 20, 150, 50)
    pause_button = pygame.Rect(220, GRID_SIZE * TILE_SIZE + 20, 150, 50)

    pygame.draw.rect(screen, GREEN, start_button)
    pygame.draw.rect(screen, GRAY, pause_button)

    start_text = font.render("Start", True, WHITE)
    screen.blit(start_text, start_text.get_rect(center=start_button.center))

    pause_text = font.render("Pause" if not game_paused else "Resume", True, WHITE)
    screen.blit(pause_text, pause_text.get_rect(center=pause_button.center))

# Main game loop
def main():
    pygame.init()
    screen = pygame.display.set_mode((GRID_SIZE * TILE_SIZE, GRID_SIZE * TILE_SIZE + 100))
    pygame.display.set_caption("AI Wumpus Game")

    font = pygame.font.SysFont(None, 36)  # Font for displaying text
    world = WumpusWorld()
    world.visited.add(world.agent_pos)  # Mark starting position as visited

    running = True
    game_paused = False
    clock = pygame.time.Clock()

    while running:
        screen.fill(BLACK)

        # Draw the game world
        world.draw(screen, font)

        # Draw the buttons
        draw_buttons(screen, font, game_paused)

        # AI makes its move based on A* algorithm if not paused
        if not world.game_over and not game_paused:
            ai_move(world)

        # Update the screen
        pygame.display.update()

        # Wait a bit before the next move
        time.sleep(1)

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                # Start button
                if pygame.Rect(50, GRID_SIZE * TILE_SIZE + 20, 150, 50).collidepoint(mouse_x, mouse_y):
                    world = WumpusWorld()  # Restart the game
                    game_paused = False
                # Pause/Resume button
                elif pygame.Rect(220, GRID_SIZE * TILE_SIZE + 20, 150, 50).collidepoint(mouse_x, mouse_y):
                    game_paused = not game_paused

        clock.tick(30)

    pygame.quit()

if __name__ == "__main__":
    main()
